# AtividadeIECMak
Atividade IEC Makefile grupo Marileia e Juliana
